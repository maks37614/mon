import type { ExchangeId, MarketType, Timeframe } from '../src/types';

/** Futures OI exists for 5m, 15m, 1h, 4h, 1d. Exchanges do not publish 1m OI bars. */
const PERIODS: Partial<Record<Timeframe, { binance: string; bybit: string; ms: number }>> = {
  '5m': { binance: '5m', bybit: '5min', ms: 300_000 },
  '15m': { binance: '15m', bybit: '15min', ms: 900_000 },
  '1h': { binance: '1h', bybit: '1h', ms: 3_600_000 },
  '4h': { binance: '4h', bybit: '4h', ms: 14_400_000 },
  '1d': { binance: '1d', bybit: '1d', ms: 86_400_000 },
};

export interface VerifiedOIPoint {
  /** Exchange timestamp in milliseconds. */
  t: number;
  /** Native open-interest quantity, not USD (USD price moves cannot fabricate OI change). */
  amount: number;
  /** USD value, only where the exchange itself reports it. */
  usd?: number;
}

export interface VerifiedOISnapshot {
  changePct: number;
  amount: number;
  timestamp: number;
  intervalMs: number;
  usd: number | null;
}

/** Reject missing, stale, duplicated, future or non-adjacent exchange snapshots. */
export function verifyOIHistory(
  rows: VerifiedOIPoint[], intervalMs: number, nowMs: number,
): VerifiedOISnapshot | null {
  if (!Number.isFinite(intervalMs) || intervalMs <= 0 || !Number.isFinite(nowMs)) return null;
  const ordered = rows.filter(row => Number.isFinite(row.t) && row.t > 0 &&
    Number.isFinite(row.amount) && row.amount > 0).sort((a, b) => a.t - b.t);
  if (ordered.length < 2 || ordered.length !== rows.length) return null;
  for (let i = 1; i < ordered.length; i++) {
    if (ordered[i].t - ordered[i - 1].t !== intervalMs) return null;
  }
  const last = ordered[ordered.length - 1], previous = ordered[ordered.length - 2];
  if (last.t > nowMs + 60_000 || nowMs - last.t > intervalMs * 2 + 90_000) return null;
  const usd = last.usd !== undefined && Number.isFinite(last.usd) && last.usd > 0
    ? last.usd : null;
  return {
    changePct: Number(((last.amount - previous.amount) / previous.amount * 100).toFixed(3)),
    amount: last.amount, timestamp: last.t, intervalMs, usd,
  };
}

export function parseBinanceOIHistory(payload: unknown): VerifiedOIPoint[] {
  if (!Array.isArray(payload)) return [];
  return payload.map((row: any) => ({
    t: Number(row?.timestamp), amount: Number(row?.sumOpenInterest),
    usd: Number(row?.sumOpenInterestValue),
  }));
}

export function parseBybitOIHistory(payload: unknown): VerifiedOIPoint[] {
  const result = payload as { retCode?: number; result?: { list?: unknown[] } } | null;
  if (!result || result.retCode !== 0 || !Array.isArray(result.result?.list)) return [];
  return result.result.list.map((row: any) => ({
    t: Number(row?.timestamp), amount: Number(row?.openInterest),
  }));
}

const cache = new Map<string, { expires: number; data: VerifiedOISnapshot | null }>();
const active = new Map<string, Promise<VerifiedOISnapshot | null>>();

/** Returns null on spot, unsupported TF or incomplete API responses; never guess zero. */
export async function fetchRegularOISnapshot(
  exchange: ExchangeId, market: MarketType, symbol: string, timeframe: Timeframe,
): Promise<VerifiedOISnapshot | null> {
  const period = PERIODS[timeframe];
  if (market !== 'futures' || !period || !/^[A-Z0-9]{3,30}$/.test(symbol)) return null;
  const key = `${exchange}:${symbol}:${timeframe}`;
  const found = cache.get(key), now = Date.now();
  if (found && found.expires > now) return found.data;
  const pending = active.get(key);
  if (pending) return pending;
  const request = (async () => {
    let value: VerifiedOISnapshot | null = null;
    try {
      const url = exchange === 'binance'
        ? `https://fapi.binance.com/futures/data/openInterestHist?symbol=${encodeURIComponent(symbol)}&period=${period.binance}&limit=3`
        : `https://api.bybit.com/v5/market/open-interest?category=linear&symbol=${encodeURIComponent(symbol)}&intervalTime=${period.bybit}&limit=3`;
      const response = await fetch(url, { signal: AbortSignal.timeout(3500) });
      if (response.ok) {
        const payload = await response.json();
        const rows = exchange === 'binance' ? parseBinanceOIHistory(payload) : parseBybitOIHistory(payload);
        // Require all requested adjacent periods (3 snapshots) before trusting change.
        if (rows.length >= 3) value = verifyOIHistory(rows.slice(0, 3), period.ms, Date.now());
      }
    } catch { /* Public APIs can fail/region-block; record unavailable, never fake data. */ }
    cache.set(key, { data: value, expires: Date.now() + (value ? 45_000 : 12_000) });
    if (cache.size > 600) cache.delete(cache.keys().next().value!);
    return value;
  })().finally(() => active.delete(key));
  active.set(key, request);
  return request;
}
