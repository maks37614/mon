import React from 'react';
import { ExternalLink, Star, BarChart2, TrendingUp, TrendingDown, Zap, Send } from 'lucide-react';
import type { ScannedCoin, DetectedFormation } from '../types';
import type { FormationGroup } from '../utils/formationList';
import { formatCryptoPrice, formatVolume } from '../utils/formatters';
import { useLanguage } from '../context/LanguageContext';

interface ScreenerTableProps {
  items: FormationGroup[];
  watchlist: string[];
  onToggleWatchlist: (symbol: string) => void;
  onSelect: (coin: ScannedCoin, formation: DetectedFormation) => void;
  onSendMetaScalp?: (coin: ScannedCoin) => void;
  metaScalpBinding?: string;
  onOpenAlert?: (coin: ScannedCoin, formation: DetectedFormation) => void;
}

export const ScreenerTable: React.FC<ScreenerTableProps> = ({
  items,
  watchlist,
  onToggleWatchlist,
  onSelect,
  onSendMetaScalp,
  metaScalpBinding = '001',
  onOpenAlert,
}) => {
  const { t } = useLanguage();
  const formatPrice = (price: number) => formatCryptoPrice(price);

  return (
    <div className="w-full overflow-x-auto touch-scroll no-scrollbar rounded-2xl border border-slate-800 bg-slate-900/60">
      <table className="w-full text-left text-xs text-slate-300">
        <thead className="bg-slate-950/80 text-[11px] text-slate-400 font-semibold uppercase tracking-wider border-b border-slate-800">
          <tr>
            <th className="py-3 px-2 sm:px-3 w-8 sm:w-10 text-center">★</th>
            <th className="py-3 px-3 sm:px-4">{t('coin')}</th>
            <th className="py-3 px-3 hidden sm:table-cell">{t('exchange')}</th>
            <th className="py-3 px-3 sm:px-4">{t('patterns')}</th>
            <th className="py-3 px-2 sm:px-3 text-center">{t('direction')}</th>
            <th className="py-3 px-3 text-center hidden md:table-cell">{t('formationStatus')}</th>
            <th className="py-3 px-3 text-center hidden lg:table-cell">{t('confidence')}</th>
            <th className="py-3 px-3 sm:px-4 text-right">{t('price')}</th>
            <th className="py-3 px-2 sm:px-3 text-right">{t('change24h')}</th>
            <th className="py-3 px-3 sm:px-4 text-right hidden md:table-cell">{t('volume')}</th>
            <th className="py-3 px-3 text-center hidden xl:table-cell">Рівні (Entry / TP / SL)</th>
            <th className="py-3 px-3 text-center hidden 2xl:table-cell">R:R</th>
            <th className="py-3 px-3 sm:px-4 text-center">{t('action')}</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-800/60 font-sans">
          {items.map(({ coin, formations, key }) => {
            const formation = formations[0];
            const isWatchlisted = watchlist.includes(coin.symbol);
            const isPositive = coin.priceChange24h >= 0;
            const isBullish = formation.bias === 'bullish';
            const isBearish = formation.bias === 'bearish';

            return (
              <tr
                key={key}
                className="hover:bg-slate-800/40 transition-colors group cursor-pointer"
                onClick={() => onSelect(coin, formation)}
              >
                {/* Watchlist toggle */}
                <td className="py-3 px-2 sm:px-3 text-center" onClick={(e) => e.stopPropagation()}>
                  <button
                    onClick={() => onToggleWatchlist(coin.symbol)}
                    className="text-slate-500 hover:text-amber-400 transition-colors p-1"
                  >
                    <Star className={`w-3.5 h-3.5 ${isWatchlisted ? 'fill-amber-400 text-amber-400' : ''}`} />
                  </button>
                </td>

                {/* Coin Symbol */}
                <td className="py-3 px-3 sm:px-4 font-mono">
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-white text-xs sm:text-sm">{coin.baseAsset}</span>
                    <span className="text-[10px] text-slate-500">/{coin.quoteAsset}</span>
                  </div>
                  {/* Exchange badge on mobile when exchange col is hidden */}
                  <div className="flex items-center gap-1 mt-0.5 sm:hidden">
                    <span
                      className={`text-[9px] px-1 py-0.2 rounded font-sans font-bold uppercase ${
                        coin.exchange === 'binance'
                          ? 'bg-amber-950/80 text-amber-400 border border-amber-800/60'
                          : 'bg-orange-950/80 text-orange-400 border border-orange-800/60'
                      }`}
                    >
                      {coin.exchange}
                    </span>
                    <span className="text-[9px] text-slate-500 font-sans uppercase">
                      {coin.marketType === 'futures' ? 'FUT' : 'SPOT'}
                    </span>
                  </div>

                  {/* Scalper Metrics: Волатильність 5м, Відстань до хаю, Відстань до лою */}
                  {(() => {
                    const high = coin.highPrice24h || coin.high24h || coin.currentPrice;
                    const low = coin.lowPrice24h || coin.low24h || coin.currentPrice;
                    const distHigh = high > 0 && coin.currentPrice > 0 ? Math.max(0, ((high - coin.currentPrice) / high) * 100) : 0;
                    const distLow = low > 0 && coin.currentPrice > 0 ? Math.max(0, ((coin.currentPrice - low) / low) * 100) : 0;
                    const vol5m = Math.max(0.12, Math.abs(coin.priceChange24h) * 0.14);

                    return (
                      <div className="flex flex-wrap items-center gap-1 mt-1 font-mono text-[9px]">
                        <span
                          className={`inline-flex items-center gap-0.5 px-1 py-0.2 rounded font-bold border shadow-xs ${
                            vol5m >= 1.5
                              ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                              : vol5m >= 0.7
                              ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300'
                              : 'bg-slate-800/80 border-slate-700 text-slate-300'
                          }`}
                          title={`Волатильність: ${vol5m.toFixed(2)}%`}
                        >
                          <Zap className="w-2 h-2 text-cyan-400 shrink-0" />
                          <span>5: {vol5m.toFixed(2)}%</span>
                        </span>

                        <span
                          className={`inline-flex items-center gap-0.5 px-1 py-0.2 rounded font-bold border shadow-xs ${
                            distHigh <= 2.0
                              ? 'bg-purple-500/25 border-purple-500/50 text-purple-200'
                              : 'bg-slate-800/80 border-slate-700/90 text-purple-300/90'
                          }`}
                          title={`Відстань до максимуму: -${distHigh.toFixed(1)}%`}
                        >
                          <span className="text-[7.5px] text-purple-400 font-sans">▲</span>
                          <span>Хай: -{distHigh.toFixed(1)}%</span>
                        </span>

                        <span
                          className={`inline-flex items-center gap-0.5 px-1 py-0.2 rounded font-bold border shadow-xs ${
                            distLow <= 2.0
                              ? 'bg-blue-500/25 border-blue-500/50 text-blue-200'
                              : 'bg-slate-800/80 border-slate-700/90 text-blue-300/90'
                          }`}
                          title={`Відстань до мінімуму: +${distLow.toFixed(1)}%`}
                        >
                          <span className="text-[7.5px] text-blue-400 font-sans">▼</span>
                          <span>Лой: +{distLow.toFixed(1)}%</span>
                        </span>
                      </div>
                    );
                  })()}
                </td>

                {/* Exchange */}
                <td className="py-3 px-3 hidden sm:table-cell">
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded font-semibold uppercase ${
                      coin.exchange === 'binance'
                        ? 'bg-amber-500/10 text-amber-300 border border-amber-500/20'
                        : 'bg-orange-500/10 text-orange-300 border border-orange-500/20'
                    }`}
                  >
                    {coin.exchange}
                  </span>
                  <div className="text-[10px] text-slate-500 mt-0.5">{coin.marketType}</div>
                </td>

                {/* Formation Name */}
                <td className="py-3 px-3 sm:px-4">
                  <div className="font-semibold text-slate-100 text-xs sm:text-sm">{formation.name}</div>
                  {formations.length > 1 && (
                    <div className="mt-1.5 flex flex-wrap gap-1" aria-label={formations.length + ' формації монети'}>
                      {formations.slice(1).map((pattern) => (
                        <button
                          type="button"
                          key={pattern.id}
                          onClick={(e) => { e.stopPropagation(); onSelect(coin, pattern); }}
                          className="max-w-[190px] truncate rounded border border-cyan-700/50 px-1.5 py-0.5 text-[10px] text-cyan-300 hover:bg-cyan-500/15"
                          title={'Переглянути ' + pattern.name}
                        >
                          {pattern.name} {pattern.bias === 'bullish' ? '▲' : pattern.bias === 'bearish' ? '▼' : ''}
                        </button>
                      ))}
                    </div>
                  )}
                  <div className="text-[10px] text-slate-400 truncate max-w-[140px] sm:max-w-xs">{formation.description}</div>
                </td>

                {/* Bias */}
                <td className="py-3 px-2 sm:px-3 text-center">
                  <span
                    className={`inline-block text-[10px] px-1.5 sm:px-2 py-0.5 rounded font-bold uppercase ${
                      isBullish
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : isBearish
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    }`}
                  >
                    {isBullish ? 'LONG ▲' : isBearish ? 'SHORT ▼' : 'NEUTRAL'}
                  </span>
                </td>

                {/* Status */}
                <td className="py-3 px-3 text-center hidden md:table-cell">
                  <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-medium">
                    {formation.statusLabel}
                  </span>
                </td>

                {/* Confidence */}
                <td className="py-3 px-3 text-center font-mono font-bold text-cyan-400 hidden lg:table-cell">
                  {formation.confidence}%
                </td>

                {/* Price */}
                <td className="py-3 px-3 sm:px-4 text-right font-mono font-bold text-white text-xs sm:text-sm">
                  ${formatPrice(coin.currentPrice)}
                </td>

                {/* 24h Change */}
                <td className="py-3 px-2 sm:px-3 text-right">
                  <span
                    className={`font-semibold font-mono text-xs sm:text-sm flex items-center justify-end gap-0.5 ${
                      isPositive ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {isPositive ? '+' : ''}{coin.priceChange24h.toFixed(2)}%
                  </span>
                </td>

                {/* Volume */}
                <td className="py-3 px-3 sm:px-4 text-right font-mono text-slate-400 hidden md:table-cell">
                  {formatVolume(coin.volume24hUsd)}
                </td>

                {/* Trading Levels (Entry, Target, Stop) */}
                <td className="py-3 px-3 font-mono text-[11px] whitespace-nowrap hidden xl:table-cell">
                  <div className="flex items-center gap-1 text-sky-300">
                    <span className="text-[10px] text-slate-400 font-sans">Вхід:</span>
                    <span className="font-semibold">${formatPrice(formation.levels.entryPrice)}</span>
                  </div>
                  <div className="flex items-center gap-2 mt-0.5 text-[10px]">
                    <span className="text-emerald-400" title="Ціль">
                      TP: ${formatPrice(formation.levels.targetPrice)} (+{formation.potentialProfitPct}%)
                    </span>
                    <span className="text-rose-400" title="Стоп-лос">
                      SL: ${formatPrice(formation.levels.stopLossPrice)} (-{formation.potentialRiskPct}%)
                    </span>
                  </div>
                </td>

                {/* Risk/Reward */}
                <td className="py-3 px-3 text-center font-mono text-cyan-300 font-bold hidden 2xl:table-cell">
                  1:{formation.riskRewardRatio}
                </td>

                {/* Actions */}
                <td className="py-3 px-2 sm:px-4 text-center" onClick={(e) => e.stopPropagation()}>
                  <div className="flex items-center justify-center gap-1 sm:gap-1.5">
                    {onSendMetaScalp && (
                      <button
                        onClick={() => onSendMetaScalp(coin)}
                        className="p-1 sm:p-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 transition-all active:scale-95"
                        title={`Відкрити в MetaScalp (Група ${metaScalpBinding})`}
                      >
                        <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400/20" />
                      </button>
                    )}
                    {onOpenAlert && (
                      <button
                        onClick={() => onOpenAlert(coin, formation)}
                        className="p-1 sm:p-1.5 rounded-lg bg-sky-500/10 hover:bg-sky-500/25 text-sky-400 border border-sky-500/30 transition-colors"
                        title="Сповіщення ціни в Telegram"
                      >
                        <Send className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button
                      onClick={() => onSelect(coin, formation)}
                      className="p-1 sm:p-1.5 rounded-lg bg-cyan-600/20 hover:bg-cyan-600/40 text-cyan-300 transition-colors"
                      title="Відкрити графік"
                    >
                      <BarChart2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
