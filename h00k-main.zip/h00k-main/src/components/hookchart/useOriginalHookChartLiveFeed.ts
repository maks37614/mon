import { useEffect, useMemo, useRef, useState } from 'react';
import type { ExchangeId, HookChartPreferences, MarketType } from '../../types';
import { adaptiveCut, atr, quantile, type MarketPrint } from './marketAnalytics';
import { calcCascadeRisk, type Candle, type Density, type Liquidation } from './engine';
import { normalizeExchangeSymbol } from '../../utils/marketSymbols';
import type { ChartDepthStatus } from '../../utils/hookChartDepthProtocol';
import { connectHookChartDepth } from './depthStream';
import { HookChartDensityBook, type DensityAutoStats } from './densityBook';

type BookLevel = { p: number; q: number };

type LiveFeedArgs = {
  exchange: ExchangeId;
  marketType: MarketType;
  symbol: string;
  settings: HookChartPreferences;
  candles: Candle[];
  replay?: boolean;
};

const BINANCE_FUTURES_API = 'https://fapi.binance.com';
const BINANCE_SPOT_APIS = ['https://data-api.binance.vision', 'https://api.binance.com'];
const BINANCE_FUTURES_WS = 'wss://fstream.binance.com/market/ws';
const BINANCE_SPOT_WS = 'wss://stream.binance.com:9443/ws';
const BYBIT_API = 'https://api.bybit.com';
const BYBIT_WS = {
  futures: 'wss://stream.bybit.com/v5/public/linear',
  spot: 'wss://stream.bybit.com/v5/public/spot',
} as const;

async function fetchBinanceJson(path: string, marketType: MarketType, signal?: AbortSignal) {
  const hosts = marketType === 'futures' ? [BINANCE_FUTURES_API] : BINANCE_SPOT_APIS;
  let lastError: unknown;
  for (const host of hosts) {
    try {
      const response = await fetch(`${host}${path}`, { signal, cache: 'no-store' });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return await response.json();
    } catch (error) {
      lastError = error;
      if (signal?.aborted) throw error;
    }
  }
  throw lastError instanceof Error ? lastError : new Error('Binance unavailable');
}

export function useOriginalHookChartLiveFeed({
  exchange,
  marketType,
  symbol: rawSymbol,
  settings,
  candles,
  replay = false,
}: LiveFeedArgs) {
  const symbol = normalizeExchangeSymbol(rawSymbol);
  const [densities, setDensities] = useState<Density[]>([]);
  const [marketPrints, setMarketPrints] = useState<MarketPrint[]>([]);
  const [liquidations, setLiquidations] = useState<Liquidation[]>([]);
  const [liquidationCut, setLiquidationCut] = useState(0);
  const [liquidationStreamLive, setLiquidationStreamLive] = useState(false);
  const [liquidationLastEventAt, setLiquidationLastEventAt] = useState<number | null>(null);
  const [densityCut, setDensityCut] = useState(0);
  const [densityAutoStats, setDensityAutoStats] = useState<DensityAutoStats>({
    baseline: 0, bidCut: 0, askCut: 0, buy5m: 0, sell5m: 0,
  });
  const [book, setBook] = useState<{ b: BookLevel[]; a: BookLevel[] }>({ b: [], a: [] });
  const [fundingRate, setFundingRate] = useState(Number.NaN);
  const [fundingHistory, setFundingHistory] = useState<number[]>([]);
  const [depthReady, setDepthReady] = useState(false);
  const [depthStatus, setDepthStatus] = useState<ChartDepthStatus>('connecting');
  const depthScopeRef = useRef('');
  const depthScope = `${exchange}:${marketType}:${symbol}:${replay}`;
  const priceRef = useRef(0);
  const atrRef = useRef(0);
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  const applyBookRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    const last = candles.at(-1);
    if (last?.c) priceRef.current = last.c;
    atrRef.current = atr(candles, 50);
  }, [candles]);

  useEffect(() => {
    const exchangeSymbol = /^[\p{L}\p{M}\p{N}]+$/u.test(symbol);
    if (replay || !exchangeSymbol) {
      depthScopeRef.current = '';
      setDepthStatus(replay ? 'disabled' : 'unavailable');
      setDensities([]);
      setMarketPrints([]);
      setBook({ b: [], a: [] });
      setDepthReady(false);
      setDensityCut(0);
      setDensityAutoStats({ baseline: 0, bidCut: 0, askCut: 0, buy5m: 0, sell5m: 0 });
      return;
    }

    let dead = false;
    let tradeSocket: WebSocket | null = null;
    let tradePing: ReturnType<typeof setInterval> | null = null;
    const depthBook = new HookChartDensityBook();
    const tradeWindow: Array<{ t: number; usd: number }> = [];
    let lastTradeThresholdCalc = 0;
    let tradeCut = 0;
    let burst: { side: 'BUY' | 'SELL'; start: number; last: number; usd: number; pv: number; count: number; id: string } | null = null;

    const clearDepth = () => {
      depthScopeRef.current = '';
      depthBook.clear();
      setDepthReady(false);
      setDensities([]);
      setBook({ b: [], a: [] });
      setDensityCut(0);
      setDensityAutoStats({ baseline: 0, bidCut: 0, askCut: 0, buy5m: 0, sell5m: 0 });
    };
    const applyBook = () => {
      if (dead) return false;
      const next = depthBook.read(settingsRef.current, atrRef.current);
      depthScopeRef.current = next.depthReady ? depthScope : '';
      if (next.price) priceRef.current = next.price;
      setDensities(next.densities);
      setBook(next.book);
      setDensityCut(next.densityCut);
      setDensityAutoStats(next.autoStats);
      setDepthReady(next.depthReady);
      if (!next.depthReady) setDepthStatus(current => current === 'live' ? 'reconnecting' : current);
      return next.depthReady;
    };
    applyBookRef.current = applyBook;
    clearDepth();
    const stopDepth = connectHookChartDepth({
      exchange, marketType, symbol,
      onBook: update => {
        if (dead || !depthBook.apply(update)) return false;
        return applyBook();
      },
      onStatus: status => {
        if (dead) return;
        setDepthStatus(status);
        if (status !== 'live') clearDepth();
      },
    });
    // Advance holding time even if the next exchange event contains no price change.
    const depthPublish = setInterval(applyBook, 1000);

    type Trade = { t: number; p: number; q: number; side: 'BUY' | 'SELL'; id: string };

    const commitBurst = () => {
      if (dead || !burst || !tradeCut || burst.usd < tradeCut) return;
      const p = burst.pv / Math.max(1, burst.usd);
      const score = Math.min(100, Math.round(100 * burst.usd / Math.max(tradeCut * 2, 1)));
      const item: MarketPrint = {
        id: burst.id, side: burst.side, t: burst.start, p, usd: burst.usd,
        count: burst.count, touches: 1, lastTouch: burst.start, score,
      };
      setMarketPrints(previous => {
        const next = [...previous];
        const index = next.findIndex(row => row.id === item.id);
        if (index >= 0) next[index] = item;
        else next.push(item);
        return next.filter(row => Date.now() - row.t < 6 * 60 * 60_000).slice(-60);
      });
    };

    const handleTrade = (trade: Trade) => {
      if (dead || !Number.isFinite(trade.p) || !Number.isFinite(trade.q) || trade.p <= 0 || trade.q <= 0) return;
      const usd = trade.p * trade.q;
      depthBook.recordAggressiveTrade({ t: trade.t, p: trade.p, usd, side: trade.side, id: trade.id });
      tradeWindow.push({ t: trade.t, usd });
      while (tradeWindow.length && trade.t - tradeWindow[0].t > 120_000) tradeWindow.shift();
      if (!tradeCut || trade.t - lastTradeThresholdCalc > 3000) {
        tradeCut = adaptiveCut(tradeWindow.map(row => row.usd), .95, .995, 2.8);
        lastTradeThresholdCalc = trade.t;
      }
      if (!burst || burst.side !== trade.side || trade.t - burst.last > 450 || trade.t - burst.start > 1400) {
        commitBurst();
        burst = { side: trade.side, start: trade.t, last: trade.t, usd, pv: trade.p * usd, count: 1, id: `${trade.side}:${trade.t}:${trade.id}` };
      } else {
        burst.last = trade.t;
        burst.usd += usd;
        burst.pv += trade.p * usd;
        burst.count += 1;
      }
      if (tradeCut && burst.usd >= tradeCut) commitBurst();
    };

    const seedTrades = async () => {
      try {
        let rows: Trade[] = [];
        if (exchange === 'binance') {
          const path = marketType === 'futures'
            ? `/fapi/v1/aggTrades?symbol=${encodeURIComponent(symbol)}&limit=1000`
            : `/api/v3/aggTrades?symbol=${encodeURIComponent(symbol)}&limit=1000`;
          const data = await fetchBinanceJson(path, marketType);
          rows = (Array.isArray(data) ? data : []).map((row: any) => ({
            t: Number(row.T) || Date.now(),
            p: Number(row.p),
            q: Number(row.q),
            side: row.m ? 'SELL' : 'BUY',
            id: String(row.a ?? row.T),
          }));
        } else {
          const category = marketType === 'futures' ? 'linear' : 'spot';
          const response = await fetch(`${BYBIT_API}/v5/market/recent-trade?category=${category}&symbol=${encodeURIComponent(symbol)}&limit=1000`, { cache: 'no-store' });
          if (!response.ok) return;
          const data = await response.json();
          rows = (data?.result?.list || []).map((row: any) => ({
            t: Number(row.time) || Date.now(),
            p: Number(row.price),
            q: Number(row.size),
            side: String(row.side).toLowerCase() === 'sell' ? 'SELL' : 'BUY',
            id: String(row.execId || row.time),
          })).sort((a: Trade, b: Trade) => a.t - b.t);
        }
        if (dead || !rows.length) return;
        tradeCut = adaptiveCut(rows.map(row => row.p * row.q), .95, .995, 2.8);
        lastTradeThresholdCalc = Date.now();
        for (const row of rows) handleTrade(row);
        commitBurst();
      } catch {}
    };
    void seedTrades();

    try {
      if (exchange === 'binance') {
        const host = marketType === 'futures' ? BINANCE_FUTURES_WS : BINANCE_SPOT_WS;
        tradeSocket = new WebSocket(`${host}/${encodeURIComponent(symbol.toLowerCase())}@aggTrade`);
        tradeSocket.onmessage = event => {
          if (dead) return;
          try {
            const row = JSON.parse(event.data);
            handleTrade({
              t: Number(row.T) || Date.now(), p: Number(row.p), q: Number(row.q),
              side: row.m ? 'SELL' : 'BUY', id: String(row.a ?? row.T),
            });
          } catch {}
        };
      } else {
        tradeSocket = new WebSocket(BYBIT_WS[marketType]);
        tradeSocket.onopen = () => tradeSocket?.send(JSON.stringify({ op: 'subscribe', args: [`publicTrade.${symbol}`] }));
        tradeSocket.onmessage = event => {
          if (dead) return;
          try {
            const message = JSON.parse(event.data);
            if (message.topic !== `publicTrade.${symbol}` || !Array.isArray(message.data)) return;
            for (const row of message.data) {
              handleTrade({
                t: Number(row.T) || Date.now(), p: Number(row.p), q: Number(row.v),
                side: String(row.S).toLowerCase() === 'sell' ? 'SELL' : 'BUY',
                id: String(row.i || row.T),
              });
            }
          } catch {}
        };
        tradePing = setInterval(() => {
          if (tradeSocket?.readyState === WebSocket.OPEN) try { tradeSocket.send(JSON.stringify({ op: 'ping' })); } catch {}
        }, 20_000);
      }
    } catch {}

    return () => {
      dead = true;
      if (applyBookRef.current === applyBook) applyBookRef.current = null;
      stopDepth();
      clearInterval(depthPublish);
      depthBook.clear();
      if (tradePing) clearInterval(tradePing);
      try { tradeSocket?.close(); } catch {}
    };
  }, [
    exchange, marketType, symbol, replay,
  ]);

  useEffect(() => {
    applyBookRef.current?.();
  }, [settings.densityAnalysis, settings.densityDiffPct, settings.densityAutoMultiplier,
    settings.densityMode, settings.densityThreshold, settings.densityTimeoutMin]);

  useEffect(() => {
    const exchangeSymbol = /^[\p{L}\p{M}\p{N}]+$/u.test(symbol);
    if (replay || !exchangeSymbol || marketType !== 'futures') {
      setLiquidations([]);
      setLiquidationCut(0);
      setLiquidationStreamLive(false);
      setLiquidationLastEventAt(null);
      return;
    }

    let dead = false;
    let socket: WebSocket | null = null;
    let ping: ReturnType<typeof setInterval> | null = null;
    let retry: ReturnType<typeof setTimeout> | null = null;
    const raw: Liquidation[] = [];

    const publish = () => {
      if (dead) return;
      const now = Date.now();
      raw.sort((a, b) => a.t - b.t);
      while (raw.length && now - raw[0].t > 30 * 60_000) raw.shift();
      if (raw.length > 1500) raw.splice(0, raw.length - 1500);
      const values = raw
        .filter(row => now - row.t <= 15 * 60_000)
        .map(row => row.usd)
        .filter(value => Number.isFinite(value) && value > 0);
      const adaptive = !values.length ? 0 : values.length < 6
        ? quantile(values, .75)
        : Math.max(quantile(values, .8), adaptiveCut(values, .8, .98, 2.5));
      const cut = values.length ? Math.max(1000, adaptive) : 0;
      setLiquidationCut(cut);
      setLiquidations([...raw]);
    };

    const push = (row: Liquidation) => {
      if (!Number.isFinite(row.p) || !Number.isFinite(row.q) || !Number.isFinite(row.t) || row.p <= 0 || row.q <= 0 || row.usd <= 0) return;
      const index = raw.findIndex(item => item.id === row.id);
      if (index >= 0) raw[index] = row;
      else raw.push(row);
      setLiquidationLastEventAt(current => Math.max(current || 0, row.t));
      publish();
    };

    const scheduleReconnect = () => {
      if (dead || retry) return;
      retry = setTimeout(() => {
        retry = null;
        connect();
      }, 2000);
    };

    const connect = () => {
      if (dead) return;
      if (ping) { clearInterval(ping); ping = null; }
      setLiquidationStreamLive(false);
      try {
        if (exchange === 'binance') {
          socket = new WebSocket(`${BINANCE_FUTURES_WS}/${symbol.toLowerCase()}@forceOrder`);
          socket.onopen = () => { if (!dead) setLiquidationStreamLive(true); };
          socket.onmessage = event => {
            if (dead) return;
            try {
              const message = JSON.parse(event.data);
              const order = message?.o;
              if (!order || String(order.s || symbol).toUpperCase() !== symbol.toUpperCase()) return;
              const p = Number(order.ap || order.L || order.p || 0);
              const z = Number(order.z || 0);
              const last = Number(order.l || 0);
              const original = Number(order.q || 0);
              const q = z > 0 ? z : last > 0 ? last : original;
              const t = Number(order.T || message.E) || Date.now();
              // Binance SELL liquidation closes a long; BUY closes a short.
              const side: Liquidation['side'] = String(order.S).toUpperCase() === 'SELL' ? 'LONG' : 'SHORT';
              push({ id: `bin:${symbol}:${String(order.i ?? order.T ?? message.E ?? t)}`, side, t, p, q, usd: p * q });
            } catch {}
          };
        } else {
          socket = new WebSocket(BYBIT_WS.futures);
          socket.onopen = () => {
            if (dead) return;
            setLiquidationStreamLive(true);
            socket?.send(JSON.stringify({ op: 'subscribe', args: [`allLiquidation.${symbol}`] }));
          };
          socket.onmessage = event => {
            if (dead) return;
            try {
              const message = JSON.parse(event.data);
              if (message.topic !== `allLiquidation.${symbol}` || !Array.isArray(message.data)) return;
              for (const row of message.data) {
                const p = Number(row.p);
                const q = Number(row.v);
                const t = Number(row.T || message.ts) || Date.now();
                // Bybit documents S as the liquidated position side: Buy => long liquidation.
                const side: Liquidation['side'] = String(row.S).toLowerCase() === 'buy' ? 'LONG' : 'SHORT';
                push({ id: `byb:${symbol}:${t}:${row.S}:${row.p}:${row.v}`, side, t, p, q, usd: p * q });
              }
            } catch {}
          };
          ping = setInterval(() => {
            if (socket?.readyState === WebSocket.OPEN) try { socket.send(JSON.stringify({ op: 'ping' })); } catch {}
          }, 20_000);
        }
        socket.onerror = () => { try { socket?.close(); } catch {} };
        socket.onclose = () => {
          if (dead) return;
          setLiquidationStreamLive(false);
          scheduleReconnect();
        };
      } catch {
        setLiquidationStreamLive(false);
        scheduleReconnect();
      }
    };

    setLiquidations([]);
    setLiquidationCut(0);
    setLiquidationLastEventAt(null);
    connect();
    const publishTimer = setInterval(publish, 2000);

    return () => {
      dead = true;
      clearInterval(publishTimer);
      if (retry) clearTimeout(retry);
      if (ping) clearInterval(ping);
      try { socket?.close(); } catch {}
    };
  }, [exchange, marketType, symbol, replay]);

  useEffect(() => {
    const exchangeSymbol = /^[\p{L}\p{M}\p{N}]+$/u.test(symbol);
    if (replay || !exchangeSymbol || marketType !== 'futures') {
      setFundingRate(Number.NaN);
      setFundingHistory([]);
      return;
    }
    let dead = false;
    let controller = new AbortController();
    setFundingRate(Number.NaN); setFundingHistory([]);

    const pull = async () => {
      try {
        if (exchange === 'binance') {
          const [premiumResponse, historyResponse] = await Promise.all([
            fetch(`${BINANCE_FUTURES_API}/fapi/v1/premiumIndex?symbol=${encodeURIComponent(symbol)}`, { signal: controller.signal, cache: 'no-store' }),
            fetch(`${BINANCE_FUTURES_API}/fapi/v1/fundingRate?symbol=${encodeURIComponent(symbol)}&limit=100`, { signal: controller.signal, cache: 'no-store' }),
          ]);
          if (!premiumResponse.ok || !historyResponse.ok) { if (!dead) { setFundingRate(Number.NaN); setFundingHistory([]); } return; }
          const premium = await premiumResponse.json();
          const history = await historyResponse.json();
          if (dead) return;
          setFundingRate(premium?.lastFundingRate == null ? Number.NaN : Number(premium.lastFundingRate));
          setFundingHistory((Array.isArray(history) ? history : []).map((row: any) => Number(row.fundingRate)).filter(Number.isFinite));
        } else {
          const [tickerResponse, historyResponse] = await Promise.all([
            fetch(`${BYBIT_API}/v5/market/tickers?category=linear&symbol=${encodeURIComponent(symbol)}`, { signal: controller.signal, cache: 'no-store' }),
            fetch(`${BYBIT_API}/v5/market/funding/history?category=linear&symbol=${encodeURIComponent(symbol)}&limit=100`, { signal: controller.signal, cache: 'no-store' }),
          ]);
          if (!tickerResponse.ok || !historyResponse.ok) { if (!dead) { setFundingRate(Number.NaN); setFundingHistory([]); } return; }
          const ticker = await tickerResponse.json();
          const history = await historyResponse.json();
          if (dead) return;
          const value = ticker?.result?.list?.[0]?.fundingRate;
          setFundingRate(ticker?.retCode === 0 && value != null ? Number(value) : Number.NaN);
          setFundingHistory((history?.result?.list || []).map((row: any) => Number(row.fundingRate)).filter(Number.isFinite));
        }
      } catch { if (!dead) { setFundingRate(Number.NaN); setFundingHistory([]); } }
    };

    void pull();
    const timer = setInterval(() => {
      controller.abort();
      controller = new AbortController();
      void pull();
    }, 60_000);

    return () => {
      dead = true;
      controller.abort();
      clearInterval(timer);
    };
  }, [exchange, marketType, symbol, replay]);

  const visibleLiquidations = useMemo(
    () => liquidationCut > 0
      ? liquidations.filter(row => row.usd >= liquidationCut).slice(-160)
      : [],
    [liquidations, liquidationCut],
  );
  const risk = useMemo(
    () => calcCascadeRisk(liquidations, liquidationCut, candles.at(-1)?.c || 0),
    [liquidations, liquidationCut, candles.at(-1)?.c],
  );
  const liquidationSource = marketType === 'futures'
    ? (exchange === 'binance' ? 'BIN forceOrder' : 'BYB allLiq')
    : '';

  const currentDepth = depthScopeRef.current === depthScope && depthReady;
  return {
    densities: currentDepth ? densities : [],
    marketPrints: marketPrints.slice(-40),
    liquidations: visibleLiquidations,
    allLiquidations: liquidations,
    liquidationCut,
    liquidationStreamLive,
    liquidationLastEventAt,
    liquidationSource,
    cascadeRisk: risk,
    densityCut: currentDepth ? densityCut : 0,
    densityAutoStats: currentDepth ? densityAutoStats : { baseline: 0, bidCut: 0, askCut: 0, buy5m: 0, sell5m: 0 },
    book: currentDepth ? book : { b: [], a: [] },
    fundingRate,
    fundingHistory,
    depthReady: currentDepth,
    depthStatus,
  };
}
